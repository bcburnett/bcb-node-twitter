dbPassword = 'mongodb://MumblitAdmin:peachpie01@mumblit.com'

module.exports = {
    mongoURI: dbPassword
};
