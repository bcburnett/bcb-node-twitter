import { html } from "../node_modules/@polymer/lit-element/lit-element.js";
export const Styles = html`
<link rel="stylesheet" href="css/all.css">
<!-- css -->
<style>
:host{
margin:0;
font-size:1rem;
}

</style>
`;