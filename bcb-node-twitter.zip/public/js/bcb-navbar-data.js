export const Buttons = [{
  id: 'Top of Page',
  icon: "fas fa-arrow-up"
}, {
  id: 'Middle of Page',
  icon: "fas fa-arrow-right"
}, {
  id: 'Bottom of Page',
  icon: "fas fa-arrow-down"
}];